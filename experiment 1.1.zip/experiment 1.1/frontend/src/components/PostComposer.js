import { useState } from "react";
import "./PostComposer.css";

const platformLimits = {
  Twitter: 280,
  Facebook: 63206,
  Instagram: 2200,
};

function PostComposer() {
  const [post, setPost] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);

  const handlePlatformChange = (platform) => {
    if (selectedPlatforms.includes(platform)) {
      setSelectedPlatforms(
        selectedPlatforms.filter((p) => p !== platform)
      );
    } else {
      setSelectedPlatforms([...selectedPlatforms, platform]);
    }
  };

  const errors = selectedPlatforms.filter(
    (platform) => post.length > platformLimits[platform]
  );

  return (
    <div className="container">
      <h1>Dynamic Post Composer</h1>

      <textarea
        placeholder="Write your post here..."
        rows="8"
        value={post}
        onChange={(e) => setPost(e.target.value)}
      />

      <h2>Select Platforms</h2>

      {Object.keys(platformLimits).map((platform) => (
        <label key={platform} className="checkbox">
          <input
            type="checkbox"
            checked={selectedPlatforms.includes(platform)}
            onChange={() => handlePlatformChange(platform)}
          />
          {platform} ({platformLimits[platform]} characters)
        </label>
      ))}

      <h3>Character Count: {post.length}</h3>

      {selectedPlatforms.length === 0 && (
        <p className="warning">
          Please select at least one platform.
        </p>
      )}

      {selectedPlatforms.map((platform) => (
        <div key={platform}>
          {post.length <= platformLimits[platform] ? (
            <p className="success">
              ✔ {platform}: Valid
            </p>
          ) : (
            <p className="error">
              ✖ {platform}: Character limit exceeded ({platformLimits[platform]})
            </p>
          )}
        </div>
      ))}

      <button
        disabled={
          errors.length > 0 || selectedPlatforms.length === 0
        }
      >
        Publish
      </button>
    </div>
  );
}

export default PostComposer;